import os
import os.path
import time
rootdir="/home/louise/Pictures/Nijigen/"
while True:        
        for parent,dirnames,filenames in os.walk(rootdir):
                for filename in filenames:        
                        #print("filename with full path:"+ os.path.join(parent,filename))
                        os.system("gsettings set org.gnome.desktop.background picture-uri file://"+os.path.join(parent,filename))
                        print("正在设置壁纸,壁纸来自:"+os.path.join(parent,filename))
                        time.sleep(600)